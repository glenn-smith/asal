
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="generator" content="RapidWeaver" />
		<link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/styles.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/colourtag-smoothblue_afghan.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/background_image/custom3.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/header/font_size/small.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/navbar/font_size/small.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/fontfamily/century.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/breadcrumb/off.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/logo/right.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/shadow/off.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/sidebar/transparency/100.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/content/transparency/90.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/navbar/transparency/90.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/sidebar/position/s_hide_n_left.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/image_size/noresize.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/navbar/border/on.css" /><link rel="stylesheet" type="text/css" href="../../rw_common/themes/usine/css/defaults/none.css" /><style type="text/css" media="all">a.new {
	font-family: Verdana, Arial, Helvetica, sans-serif;	color: #92499E;	font-weight: bold;}
a.new:hover {	color:#FFFFFF;	font-family: Verdana, Arial, Helvetica, sans-serif;	font-weight: bold;}</style><script type="text/javascript" src="../../rw_common/themes/usine/javascript.js"></script>
		<title>Afghan Stray Animal League</title>
	</head>

	<body class="photo-background">
	
		<div class="photo-navigation">
			<p class="photo-title">Afghan Stray Animal League</p>
			<p class="photo-caption"></p>
			<p class="photo-links"><a href="../familyphotos.php">family photos</a> | <a href="page2-1041-full.php">Previous</a> | <a href="page2-1043-full.php">Next</a></p>
		</div>
		
		<img class="photo-frame" src="page2-1042-full.jpg" alt="Loading Image" width="640" height="480"/>
			
		
			
	</body>

</html>