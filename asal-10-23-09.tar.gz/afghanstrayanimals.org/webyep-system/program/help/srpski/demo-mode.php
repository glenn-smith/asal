<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">zatvori pomoc</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1> 
        <?php echo $webyep_sProductName?>
        Pomoc: Demo-modus</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" --> 
<p>U demo-modusu mozete koristiti celokupan obim funkcija 
  <?php echo $webyep_sProductName?>
  -a . Jedina razlika u odnosu na normalnu upotrebu je u tome da se dodatni demo-modus 
  prozor uvek otvara pri prvom otvaranju sajta i svaki posetilac moze da ga vidi.</p>
<h3>Zasto 
  <?php echo $webyep_sProductName?>
  radi u demo-modusu?</h3>
<p>Zato sto jos nije ubacen korektan licenc-kod.<br>
  Licenc-kod je korektan ako:</p>
<ul>
  <li>pripada tacno i konkretno Vasoj web adresi (na primer &quot;www.firma.com&quot;)<br>
    <strong>Paznja:</strong> Ako je vas web sajt na nekoj drugoj adresi, potreban 
    Vam je pod odredjenim uslovima dodatni kod.<br>
    obratite se u tom slucaju <a href="mailto:webyep@obdev.at?subject=WebYep%2BZweitcode">nama</a>.</li>
  <li>pripada konkretno upotrebljenoj verziji 
    <?php echo $webyep_sProductName?>
    -a </li>
</ul>
<h3>Kako da dobijem licenc-kod?</h3>
<p>Kod mozete da nabavite preko <a href="http://www.obdev.at/webyep/order-de.html" target="webyep_order">naseg 
  web sajta</a>.</p>
<h3>Kako da ubacim svoj licenc-kod?</h3>
<ul>
  <li>Zatvorite svoj Browser (zatvorite <em>sve</em> prozore Browser-a).</li>
  <li>Otvorite jednu stranicu Vaseg web sajta, na kome je instaliran 
    <?php echo $webyep_sProductName?>
    . </li>
  <li>Pojavice se demo-modus prozor.</li>
  <li>Upisite u za to predvidjenom polju svoj licenc-kod.</li>
  <li>Kliknite na &quot;licenc-kod sacuvati&quot;</li>
</ul>
 <span class="textButton">&lt;<a href="javascript:window.close();">zatvori pomoc</a>&gt;</span> 
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
