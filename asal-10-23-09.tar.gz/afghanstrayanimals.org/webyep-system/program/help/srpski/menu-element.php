<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">zatvori pomoc</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1> 
        <?php echo $webyep_sProductName?>
        Pomoc: Meni</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" --> 
<h3>Opis</h3>
<p>U prozoru za obradu mozete da menjate pojedine delova menija. Mozete da dodajete 
  dnove tacke u meni, da menjate ili brisete postojece, kao i da menjate njihov 
  raspored (cak i kasnije).</p>
<p>Obratite paznju na to da ce sve promene biti vidljive neposredno posle klika 
  na &quot;memorisi&quot;, kao i na to da je ovaj postupak nepovratan!</p>
<h3>Postupak</h3>
<p><b>Dodavanje nove tacke u meni</b></p>
<p>Upisite oznaku nove tacke za meni u zato predvidjeno polje u donjem delu i 
  kliknite na &quot;ubaci&quot;.</p>
<p><b>Menjanje takaka u meniju</b></p>
<p>Selekujte tacku iz liste koju hocete da menjate, upisite novi naziv u za to 
  predvidjeno polje u donjem delu i kliknite na&quot;promeni&quot;.</p>
<blockquote> 
  <p><strong>Vazno:</strong> <em>Prvo</em> selektujte stari naziv a <em>tek onda</em> 
    upisite novi naziv i ne zaboravite da kliknete na <em>&quot;promeni&quot;</em>.</p>
</blockquote>
<p><b>Brisanje tacaka iz menija</b></p>
<p>Selektujte tacku koju zelite da izbrisete i kliknite na &quot;obrisi&quot;. 
  Pojavice se pitanje tipa &quot;Zaista obrisati...?&quot;, koje cete potvrditi. 
  Sam postupak brisanja sa web sajta ce biti sproveden tek kad kliknete na &quot;sacuvaj&quot;.</p>
<p><b>Sortiranje menija</b></p>
<p>Selektujte tacku menija koju zelite da pomerite i kliknite na &quot;gore&quot; 
  odnosno &quot;dole&quot;.</p>
<p><b>Uvlacenje tacaka menija odnostno formiranje podtacaka</b></p>
<p>Da bi se formirala podtacka u meniju dovoljno je da se taser za pauzu pritisne 
  nekoliko puta (ili da se upise par &quot;_&quot; donjih crtica) pre samog naziva 
  tacke. Znaci, ako naziv jedne tacke u meniju: 
<blockquote> 
  <p>umesto </p>
  <p>Tacka u meniju</p>
  <p>jednostavno</p>
  <p>&nbsp;&nbsp;&nbsp;&nbsp;Tacka u meniju</p>
  <p>upisete, dakle nekoliko praznih polja ispred teksta, onda ce ta tacka menija 
    biti uvucena i na taj nacin ce postati podtacka.</p>
</blockquote>
<p><b>Neaktivina tacka u meniju (naslov)</b></p>
<p>Da bi se formirala neaktivna tacka u meniju koji nece moci da se klikne (da 
  bi se na primer postavio naslov na grupu tacaka u meniju) dovoljno je da se 
  ispred date tacke upise tarabica (#). Znaci, ako</p>
<blockquote> 
  <p>umesto</p>
  <p>Tacka u meniju</p>
  <p>jednostavno</p>
  <p>#Tacka u meniju</p>
</blockquote>
<p>upisete, dakle # na sam pocetak teksta, onda ce ta tacka biti neaktivna.</p>
<h4>Novi red u meniju</h4>
<p>Ako je naziv neke tacke u meniju predugacak i pravi problem u samom izgledu 
  sajta, podelite ga u vise redova na taj nacin sto cete na odgovarajucem mestu 
  (posle crtice za nastavak ili na pocetku reci) upisati &quot;\&quot; (backslash). 
  Znaci, ako upisete </p>
<blockquote> 
  <p>umesto </p>
  <p>Jako dugi naziv u meniju</p>
  <p>jednostavno </p>
  <p>Jako dugi\naziv u meniju</p>
</blockquote>
<p>onda ce se posle reci &quot;dugi&quot; pojaviti novi red..</p>
<p><strong>Cuvanje</strong></p>
<p><span class="remark">Kliknite na &quot;sacuvaj&quot;,posto ste zavrsili sa 
  promenama u meniju. Posle klika na &quot;sacuvaj&quot; se prozor za upisivanje 
  zatvara i mozete da vidite svoj web sajt sa promenjenim menijem.<br>
  (u retkim slucajevima morate u Browser-u da aktuelizujete svoj sajt</span><span class="remark">)</span></p>
 <span class="textButton">&lt;<a href="javascript:window.close();">zatvori pomoc</a>&gt;</span> 
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
