<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Menu</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<h3>Description</h3>
<p>The &quot;Edit Menu&quot; esta janela é usada para adicionar / remover menu items alterando a sua ordem ou properiedades..</p>
<p>Tenha atenção que as alterações efectuadas só serão desencadeadas após clicar &quot;Save&quot; button
  but <strong>depois disso não poderão ser recuperadas para a versão anterior.</strong></p>
<h3>Usage</h3>
<p><b>Adicionar um item ao menu</b></p>
<p>Para adicionar um item ao menu, insira o titulo do item no campo de texto (no fim da janela) e clique no &quot;add&quot; butão.</p>
<p><b>Alterrar um item do menum</b></p>
<p>Selecione o item que se quer alterar, insira o novo textono campo de texto elique no &quot;change&quot; butão.</p>
<blockquote>
   <p><b>Importante:</b> <i>First</i> Selecione o item que quer alterar, <i>depois</i> insira o texto e clique no <i>&quot;change&quot;</i> butão !</p>
</blockquote>
<p><b>Apagar items do menu</b></p>
<p>Selecione os items que quer deletar e clique no &quot;remove&quot; butão. Irá apareçer de seguida uma janela para confirmação da operação (&quot;Really remove item...?&quot;) - click &quot;yes&quot; para deletar o item.Este só será deletado efectivamente a partir do momento em que clique no &quot;Save&quot; butão.</p>
<p><b>Ahuste do menu </b><b>items</b></p>
<p>Selecione um item do menu, e clique nos icons para cima/para baixo para mover o item.</p>
<p><b>Criar um sub-menu</b></p>
<p>Para alterar um menu item num sub-menu (indent) coloque espaços (ou underscores, &quot;_&quot;) no inicio do titulo do titulo do item. Se alterar o titulo dos items
<blockquote>
<span class="remark">from</span><br>
   <br>
Some menu item<br>
   <br>
   <span class="remark">to</span><br>
   <br>
   &nbsp;&nbsp;&nbsp;&nbsp;Alguns items do menu</blockquote>
<p>insira alguns espaços no principo do titulo do item. Como resultado este item seerá posicionado (ident) para a direita  &#8211; dependendo do numero de espaços que der.</p>
<p><b>Menu item inactivo </b></p>
<p>Para colocar um titulo por cima de uma secção do menu, poderá criar um item inactivo no menu (que não é clicável) através da inserção do caracter (&quot;#&quot;) no inicio do seu titulo. Assim se alterar um titulo de um item</p>
<blockquote>
<span class="remark">from</span><br>
   <br>
A menu section<br>
   <br>
   <span class="remark">to</span><br>
   <br>
   #A menu section</blockquote>
<p>O item estará inactivo, não clicável e será mostrado como uma secção do titulo do menu.</p>
<h4>Cortar um menu que seja longo</h4>
<p>Se um titulo de um menu for demasiado longo, poderá afectar visualmente o display dos menus (ex. crescer na horizontal). Se isto aconteçer, poderá separar o titulo do menu em questão, inseririndo este caractera &quot;\&quot; character (backslash) no sitio em que pretende efectuar a separação  (e.g. after a dash or space). Assim ao alterar um item do menu</p>
<blockquote> <span class="remark">from</span><br>
    <br>
  A quite long menu item text<br>
  <br>
  <span class="remark">to</span><br>
  <br>
  A quite long\menu item text</blockquote>
<p>you are inserting a line break after &quot;long&quot;.</p>
<p></p>
<p><b>Saving</b></p>
<p>Depois de efectuar as alterações, clique no &quot;Save&quot; butão. A partir daqui as alterações efectuadas serão reais sendo a janela fechada. Depois disto, o menu alterado será mostrado na sua página.<br>
  <span class="remark">Poderá ter de clicar em &quot;Reload
  Page&quot; button
no seu browser para ver a sua página com a ultima versão.</span></p>
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
