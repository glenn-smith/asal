<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Short
      Text</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<h3>Description</h3>
<p>A &quot;Descritivot&quot; pode ser qualquer curto texto como um cabeçalho, um nome e consiste normalmente numa unica linha de texto. Contráriamente ao elemento longo num curto texto, a formatação é definida pelo web designer.</p>
<h3>Uso</h3>
<p>Insira o seu texto no campo respectivo e clique&quot;save&quot;.</p>
<p>A janela de edição irá fechar depois do SAVE e o texto alterado irá apareçer na página.<br>
  <span class="remark">Nalguns casos terá de clicar em&quot;Reload Page&quot; No seu web browser.</span></p>
 <span class="textButton">&lt;<a href="javascript:window.close();">close
window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
