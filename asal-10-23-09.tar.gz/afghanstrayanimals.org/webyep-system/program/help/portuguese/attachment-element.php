<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: File
      Attachment</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" -->
<h3>DescriÁ„o</h3>
<p>Com esta janela &quot;de envio de ficheiros - attachments &quot; voce pode inserir, ou deletar documentos
no seu site, fazendo a gestão remota dos documentos.</p>
<h3>Uso</h3>
<p><b>Mudar ficheiro:</b></p>
<p>Clique no &quot;Browse...&quot; butão para selecionar qual o ficheiro que pretende carregar
(upload) para a sua página. Selecione este na janela de selecão dos ficheiros que estão no seu computador e clique &quot;OK&quot; (or &quot;Open&quot;). Depois clique &quot;Save&quot; para iniciar o carregamento do ficheiro.</p>
<p><i>Remark:</i> ATTN o carregamento do ficheiro para a sua página, do seu computador local para o servidor http, onde o seu site reside, pode demorar uns minutos dependendo de diversos factores (congestionamentos diversos, velocidade da sua ligaçaõ, etc).</p>
<p><b>Delete de ficheiro:</b></p>
<p>Clique no &quot;Delete&quot; butão para remover na página e deletá-lo do servidor http.</p>
<p>Depois de clicar &quot;Save&quot; ou &quot;Delete&quot; a janela de edição vai fechar e a página alterada ser mostrada.<br>
  <span class="remark">Nalguns casos tem de ser carregado no&quot;Reload
  Page&quot; but„o
do seu browser internet (que usa para navegar nas p·ginas web).</span></p>

<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
