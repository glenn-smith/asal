<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: <?php echo $webyep_sProductName?>
      is not activated</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" -->
<p><?php echo $webyep_sProductName?> Não se consegue escrever qualquer dado porque as permissões do ficheiro não foram parameterizadas correctamente.</p>
<p>Contacte o administrador do servidor http &quot;activate&quot;
  <?php echo $webyep_sProductName?>.</p>
<p>Ou veja a documentação em (&quot;Installation on the web server / Activation&quot;)
  on how to activate <?php echo $webyep_sProductName?>.</p>
<p class="remark"><strong>Technical Remark:</strong> São necessárias as seguintes permissões para o ficheiro &quot;read/write/execute&quot; para
  &quot;all&quot; (unix mode 0777) para a pasta &quot;data&quot; dentro da pasta webyep-system.</p>
 <span class="textButton">&lt;<a href="javascript:window.close();">close
window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
