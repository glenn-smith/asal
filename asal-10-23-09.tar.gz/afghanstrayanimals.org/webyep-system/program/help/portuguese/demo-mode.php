<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Demo
      Mode</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" -->
<p>Nesta versão&quot;Demo&quot; todas as funções <?php echo $webyep_sProductName?> estão disponiveis. A única diferença, em relaçaõ à versão com licença, è que irá apareçer uma janela de aviso &quot;Demo Mode&quot; a &quot;Demo
  Notice&quot; sempre que aceder à sua página.</p>
<h3>porque está a correr em modo Demo <?php echo $webyep_sProductName?> A correr em modo Demo &quot;Demo Mode&quot;?</h3>
<p>porque não existe uma licença válida instalada.<br>
  Uma licença é válida se:</p>
<ul>
  <li>Se corresponder exactamente ao nome de dominio usado
      (domain).<br>
      Atenção: se o seu site possui diversos nomes de dominio associados, poderá ter diversas licenças atribuidas. Neste caso estas são gratuitas. Contacte <a href="mailto:webyep@obdev.at?subject=WebYep%2Badditional%2Blicense%2Bcodes">Contacte
      nos</a> para
      obter estas licenças.</li>
  <li>Corresponde <?php echo $webyep_sProductName?> ¿ versão usada.</li>
</ul>
<h3>Como obter uma licença ?</h3>
<p>Pode obter uma licença <?php echo $webyep_sProductName?> no <a href="http://www.obdev.at/webyep/order.html" target="webyep_order">nosso site</a>.</p>
<p>Como registar o produto depois de aquisição da licença ?</p>
<ul>
  <li>Feche o seu web browser (termine <em>all</em> as janelas do seu web browser).</li>
  <li>Lançe o seu web browser e abra a página onde está a usar <?php echo $webyep_sProductName?> =&gt;
    A &quot;janela de Demo&quot; ir· apareÁer.</li>
  <li>Escreva o seu código de registo recebido no campo de texto na &quot;janela&quot;Demo.</li>
  <li>Clique no &quot;guardar licença &quot; butão.</li>
</ul>
<h3>&nbsp;</h3>

<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
