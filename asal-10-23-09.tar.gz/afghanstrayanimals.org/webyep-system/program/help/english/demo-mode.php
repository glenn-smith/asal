<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Demo
      Mode</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<p>In the &quot;Demo Mode&quot; all functions of <?php echo $webyep_sProductName?> are available. The only
  difference to the licensed mode is, that in &quot;Demo Mode&quot; a &quot;Demo
  Notice&quot; window will pop
  up every first time you access your website.</p>
<h3>Why is <?php echo $webyep_sProductName?> running in &quot;Demo Mode&quot;?</h3>
<p>Because there is no valid license code installed.<br>
  A license code is valid if:</p>
<ul>
  <li>It exactly matches the websites name
      (domain).<br>
      Caution: If you refer to your website by several names, you might need
      (free) additional license codes. Please <a href="mailto:webyep@obdev.at?subject=WebYep%2Badditional%2Blicense%2Bcodes">contact
      us</a> to
      get these.</li>
  <li>It matches the <?php echo $webyep_sProductName?> version used.</li>
</ul>
<h3>How can I get a license code?</h3>
<p>You can purchase <?php echo $webyep_sProductName?> license codes at <a href="http://www.obdev.at/webyep/order.html" target="webyep_order">our website</a>.</p>
<p>How do I save my license code?</p>
<ul>
  <li>Quit your web browser (close <em>all</em> windows of the web browser).</li>
  <li>Launch it again and open a page of your website that's using <?php echo $webyep_sProductName?> =&gt;
    The &quot;Demo-Notice&quot; window will pop up.</li>
  <li>Enter your license code into the textfield in the &quot;Demo-Notice&quot; window.</li>
  <li>Klick the &quot;save license code&quot; button.</li>
</ul>
<h3>&nbsp;</h3>
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
