<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Menu</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<h3>Description</h3>
<p>The &quot;Edit Menu&quot; window is used to add/remove menu items and change their order
  and/or properties.</p>
<p>Please remind that all changes are not applied to the page until you click
  the &quot;Save&quot; button
  but <strong>then can not be undone!</strong></p>
<h3>Usage</h3>
<p><b>Add menu item</b></p>
<p>To add a menu item, enter the items title in the text field (at the window
  bottom) and click the &quot;add&quot; button.</p>
<p><b>Change menu item</b></p>
<p>Select the item you want to change in the list, enter the new title into the
  text field and click the &quot;change&quot; button.</p>
<blockquote>
   <p><b>Important:</b> <i>First</i> select the item you want to change, <i>then</i> enter
     the text and then click the <i>&quot;change&quot;</i> button!</p>
</blockquote>
<p><b>Delete menu item</b></p>
<p>Select the item you want to delete and then click the &quot;remove&quot; button. A confirmation
  panel will appear (&quot;Really remove item...?&quot;) - click &quot;yes&quot; to delete the item.
  Note that the item will not really be deleted until you safe the menu by clicking
  the &quot;Save&quot; button.</p>
<p><b>Reorder menut </b><b>items</b></p>
<p>Select an item and click the up/down icon to move it.</p>
<p><b>Indent menu item (create submenus)</b></p>
<p>To make a menu item into a submenu item (indent it) simply put some spaces
  (or underscores, &quot;_&quot;) at the beginning of the items title. If you
  change an items title
<blockquote>
<span class="remark">from</span><br>
   <br>
Some menu item<br>
   <br>
   <span class="remark">to</span><br>
   <br>
   &nbsp;&nbsp;&nbsp;&nbsp;Some menu item</blockquote>
<p>by inserting some spaces an the beginning of the items titel, this item will
  be indented to the right &#8211; how far depends on the number of spaces you insert.</p>
<p><b>Inactive menu item (section titel)</b></p>
<p>To place a title above a menu section (a group of menu or submenu items) you
  can create an inactive menu item (that can not be clicked) by placing a hash
  sign (&quot;#&quot;) at the beginning of its title. So, if you change an items
  title</p>
<blockquote>
<span class="remark">from</span><br>
   <br>
A menu section<br>
   <br>
   <span class="remark">to</span><br>
   <br>
   #A menu section</blockquote>
<p>the item will be inactive (non clickable) and be displayed as a menu section
  title.</p>
<h4>Breaking up long menu item titels</h4>
<p>When an item titel is too long it can visually distort the menu display (e.g.
  by stretching its width). If this happens, you can break up the items titel
   into several lines by inserting a &quot;\&quot; character (backslash) into the titel
  where appropriate (e.g. after a dash or space). So by changing a menu items
  text</p>
<blockquote> <span class="remark">from</span><br>
    <br>
  A quite long menu item text<br>
  <br>
  <span class="remark">to</span><br>
  <br>
  A quite long\menu item text</blockquote>
<p>you are inserting a line break after &quot;long&quot;.</p>
<p></p>
<p><b>Saving</b></p>
<p>After making you changes click the &quot;Save&quot; button. This will make all your
  changes permanent and close the editor window. After that, the changed menu
  will be displayed in your web page.<br>
  <span class="remark">In some rare cases you might need to klick the &quot;Reload
  Page&quot; button
of you web browser.</span></p>
<span class="textButton">&lt;<a href="javascript:window.close();">close window</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
