<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">Zamknij okno</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Pomoc: Kr&oacute;tki Tekst</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" -->
<h3>Opis</h3>
<p>&quot;Kr&oacute;tki Tekst&quot; mo&#380;e by&#263; dowolnym tekstem takim jak nag&#322;&oacute;wek, nazwa produktu i z regu&#322;y zawiera jedn&#261; linijk&#281;. W odr&oacute;&#380;nieniu od elementy &quot;D&#322;ugi Tekst&quot; formatowanie jest ustawione z g&oacute;ry.</p>
<h3>Obs&#322;uga</h3>
<p>Wpisz sw&oacute;j tekst w pole tekstowe i kliknij &quot;Zapisz&quot;.</p>
<p>Okno edytora zamknie si&ecirc; i zostanie wy&para;wietlona zmieniona strona.<br>
  <span class="remark">W niekt&oacute;rych przypadkach wymagane b&ecirc;dzie naci&para;ni&ecirc;cie przycisku &quot;Od&para;cie&iquest; ston&ecirc;&quot; w przegl&plusmn;darce internetowej.</span></p>
 <span class="textButton">&lt;<a href="javascript:window.close();">Zamknij okno</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
