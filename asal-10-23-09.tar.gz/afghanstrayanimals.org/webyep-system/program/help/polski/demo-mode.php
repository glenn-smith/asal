<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">Zamknij okno</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Pomoc: Tryb Demo</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" -->
<p>W &quot;Trybie Demo&quot; wszystkie funkcje 
  <?php echo $webyep_sProductName?>
  s&#261; dost&#281;pne. Jedyna r&oacute;&#380;nica pomi&#281;dzy wersj&#261; licencjonowan&#261; jest taka, &#380;e pojawia si&#281; &quot;Nota Demo&quot; przed ka&#380;dym werj&#347;ciem na ston&#281;.</p>
<h3>Dlaczego 
<?php echo $webyep_sProductName?>
 uruchamia si&#281; w &quot;Trybie Demo&quot;?</h3>
<p>Poniewa&#380; nie zosta&#322; zainstalowany w&#322;a&#347;ciwy kod licenyjny.<br>
Kod licenyjne jest poprawny je&#347;li:</p>
<ul>
  <li>Dok&#322;adnie zgadza si&#281; z nazw&#261; strony (domen&#261;).<br>
  Ostrze&#380;enie: Je&#347;li do tej strony odnosi si&#281; kilka domen potrzebujesz dodatkowych (darmowych) kod&oacute;w licencyjnych. Prosimy o <a href="mailto:webyep@obdev.at?subject=WebYep%2Badditional%2Blicense%2Bcodes">kontakt</a> aby je usuzka&#263;.</li>
  <li>Zgadza si&#281; z u&#380;ywan&#261; wersj&#261; <?php echo $webyep_sProductName?>.</li>
</ul>
<h3>Jak uzyska&#263; kod licencyjny?</h3>
<p>Kod licencyjny  <?php echo $webyep_sProductName?> mo&#380;na ku&#263; na  <a href="http://www.obdev.at/webyep/order.html" target="webyep_order">naszej stronie</a>.</p>
<p>Jak zapisa&#263; kod licencyjny?</p>
<ul>
  <li>Wyjd&#378; z przegl&#261;darki (zamknij wszystkie okna przegl&#261;darek).</li>
  <li>Uruchom przegl&#261;dark&#281; ponownie i otw&oacute;rz swoj&#261; stron&#281; u&#380;ywaj&#261;c&#261;  
    <?php echo $webyep_sProductName?> =&gt;
    pojawi si&#281; okno &quot;Tryb Demo&quot;.</li>
  <li>Wpisz kod licencyjny w odpowiednie pole  okna &quot;Nota Demo&quot;.</li>
  <li>Kliknij &quot;Zapisz kod licencyjny&quot;.</li>
</ul>
<h3>&nbsp;</h3>

<span class="textButton">&lt;<a href="javascript:window.close();">Zamknij okno</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
