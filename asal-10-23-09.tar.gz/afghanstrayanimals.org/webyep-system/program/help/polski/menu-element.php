<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html><!-- #BeginTemplate "/Templates/help-1.1-en.dwt" --><!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<!-- #BeginEditable "doctitle" -->
<title><?php echo $webyep_sProductName?></title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">Zamknij okno</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Pomoc: Menu</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<!-- #BeginEditable "content" -->
<h3>Opis </h3>
<p>Okno &quot;Edytuj Menu&quot; jest u&#380;ywane do dodawania/usuwania element&oacute;w menu oraz zmieniania ich kolejno&#347;ci i/lub w&#322;asno&#347;ci.</p>
<p>Prosimy pami&#281;ta&#263;, &#380;e wszystkie czynno&#347;ci nie s&#261; stosowane do czasu klikni&#281;cia przycisku &quot;Zapisz&quot;. Po klikni&#281;ciu <strong>nie mog&#261; by&#263; cofjni&#281;te!</strong></p>
<h3>Obs&#322;uga</h3>
<p><b>Dodawanie elementu menu</b></p>
<p>Abu doda&#263; element menu wpisz nazw&#281; elementu w polu tekstowym i naci&#347;nij przycisk &quot;Dodaj&quot;.</p>
<p><b>Zmiana elementu menu</b></p>
<p>Wybierz z listy element menu do zmiany, wpisz now&#261; nazw&#281; i naci&#347;nij przycisk &quot;Zmie&#324;&quot;.</p>
<blockquote>
  <p><b>Wa&#380;ne:</b> <i>Najpierw</i> wybierz element do zmiany,  <i>nast&#281;pnie  </i> wpisz nazw&#281; i wtedy kliknij przycisk <i>&quot;Zmie&#324;&quot;</i>!</p>
</blockquote>
<p><b>Usuwanie elementu menu</b></p>
<p>Wybierz element menu, kt&oacute;ry chcesz usun&#261;&#263; i kliknij przycisk &quot;Usu&#324;&quot;. Pojawi si&#281; panel potwierdzaj&#261;cy  (&quot;Czy na pewno chcesz usun&#261;&#263; element...?&quot;) - naci&#347;nij &quot;tak&quot; aby usun&#261;&#263; element.
  Zauwa&#380;, &#380;e element nie zostanie usuni&#281;ty ca&#322;kowicie dokp&oacute;ki nie naci&#347;niesz przyciku &quot;Zapisz&quot;.</p>
<p><b>Zmiana kolejno&#347;ci element&oacute;w</b></p>
<p>Wybierz element i naci&#347;nij ikon&#281; g&oacute;ra/d&oacute;&#322; aby przesun&#261;&#263; element.</p>
<p><b>Zagnie&#380;dzanie element&oacute;w menu (tworzenie podmenu)</b></p>
<p>Aby uczyni&#263; z elementu element podmenu po prostu wstaw przed nim kilka spacji 
  (lub podkre&#347;link&oacute;w, &quot;_&quot;) na pocz&#261;tku nazwy elementu. Je&#347;li zmienisz nazw&#281; elementu 
<blockquote>
<span class="remark">z</span><br>
   <br>
Elelement menu <br>
   <br>
   <span class="remark">na</span><br>
   <br>
   &nbsp;&nbsp;&nbsp;&nbsp;Element menu</blockquote>
<p>Poprzez dodanie kilku spacji na pocz&#261;tku to ten element b&#281;dzie zagnie&#380;dzony w prawo - o tym jak bardzo decyduje wstawiona liczba spacji przed elementem.</p>
<p><b>Nieaktywny element menu (tytu&#322; sekcji)</b></p>
<p>Aby wstawi&#263; tytu&#322; nad sekcj&#261; element&oacute;w menu (grup&#261; element&oacute;w menu lub podmenu) mo&#380;esz stworzy&#263; niekatywny element menu (nie b&#281;dzie m&oacute;g&#322; by&#263; klikni&#281;ty) poprzez wstawienie znaku &quot;#&quot; na pocz&#261;tku tytu&#322;u. Je&#347;li wi&#281;c zmienisz tytu&#322; menu: </p>
<blockquote>
<span class="remark">z</span><br>
   <br>
Sekcja menu<br>
   <br>
   <span class="remark">na </span><br>
   <br>
#Sekcja menu</blockquote>
<p>element b&#281;dzie nieaktywny (nieklikalny) i zostanie wy&#347;wietlony jako tytu&#322; sekcji menu.</p>
<h4>&#321;amanie d&#322;ugich nazw element&oacute;w menu</h4>
<p>Gdy nazwa elementu menu jest zbyt d&#322;uga mo&#380;e zaburza&#263; wygl&#261;d strony (np. rozszerza&#263; tabel&#281;). Je&#347;li taka sytuacja ma miejsce mo&#380;esz podzieli&#263; nazw&#281; na kilka linii poprzez umieszcznie znak&oacute;w &quot;\&quot; w odpowiednich miejscach nazwy (np. w miescu jednej ze spacji lub my&#347;lnika. Je&#347;li wi&#281;c zmienisz nazw&#281; elementu</p>
<blockquote> <span class="remark">z</span><br>
    <br>
  Dosyc d&#322;uga nazwa elementu menu<br>
  <br>
  <span class="remark">na</span><br>
  <br>
  Do&#347;&#263; d&#322;uga\nazwa elementu menu</blockquote>
<p>to podzielisz nazw&#281; po s&#322;owie &quot;d&#322;uga&quot;.</p>
<p></p>
<p><b>Zapisywanie</b></p>
<p>Po dokonaniu wszystkich zmian naci&#347;nij przycisk &quot;Zapisz&quot;. Spowoduje to trwa&#322;&#261; zmian&#281; element&oacute;w menu i zamkni&#281;cie okna edycji. Po tym zmiany zostan&#261; wy&#347;wietlone na twojej stronie.<br>
<span class="remark">W niekt&oacute;rych przypadkach wymagane b&ecirc;dzie naci&para;ni&ecirc;cie przycisku &quot;Od&para;cie&iquest; ston&ecirc;&quot; w przegl&plusmn;darce internetowej.</span>s</p>

<span class="textButton">&lt;<a href="javascript:window.close();">Zamknij okno</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
