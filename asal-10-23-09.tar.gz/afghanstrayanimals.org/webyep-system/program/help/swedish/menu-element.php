<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->

<title><?php echo $webyep_sProductName?>
</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">st&auml;ng f&ouml;nstret</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?>
   : Redigera meny</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>

<p>F&ouml;nstret Redigera meny anv&auml;nds f&ouml;r att:<br>
  - 
  l&auml;gga till/ta bort menyobjekt<br>
  - &auml;ndra menyobjekts inb&ouml;rdes ordning<br>
  - &auml;ndra menyobjekts inst&auml;llningar.</p>
<p>Inga &auml;ndringar &auml;r utlagda p&aring; webbsidan f&ouml;rr&auml;n du klickat Spara. Var dock medveten om att Spara-knappen &auml;ven st&auml;nger dialogrutan!</p>
<h3>G&ouml;r s&aring; h&auml;r</h3>
<p><b>L&auml;gga till  ett menyobjekt</b></p>
<p>Skriv ett namn p&aring; menyobjektet i det nedre textf&auml;ltet. Klicka p&aring; L&auml;gg till.  </p>
<p><b>&Auml;ndra ett menyobjekt</b></p>
<p>Markera  menyobjektet du vill &auml;ndra i listan. R&auml;tta texten i det nedre textf&auml;ltet och klicka sedan knappen &Auml;ndra.</p>
<blockquote>
   <p><b>Viktigt:</b> <i>1.</i> v&auml;lj menyobjekt, <i>2.</i> r&auml;tta texten, <i>3.</i> klicka &Auml;ndra</p>
</blockquote>
<p><b>Radera menyobjekt</b></p>
<p>Markera menyobjektet och klicka knappen Radera. En kontrollfr&aring;ga f&ouml;ljer  &ndash; klicka OK-knappen f&ouml;r att verkst&auml;lla. Observera att menyobjektet inte &auml;r raderat f&ouml;rr&auml;n  menyn sparats. </p>
<p><b>&Auml;ndra ordning p&aring; menyobjekt</b></p>
<p>Markera ett menyobjekt och klicka upp-/nerpilarna f&ouml;r att &auml;ndra ordningen i listan. </p>
<p><b>Skapa undermenyer (med indrag)</b></p>
<p>G&ouml;r  indrag m h a mellanslag eller <i>underscore</i> f&ouml;r att skapa   undermenyer. <br>
  &Auml;ndra en menytitel 
<blockquote>
  <span class="remark">fr&aring;n</span><br>
  <br>
  Menytitel<br>
  <br>
  <span class="remark">till</span><br>
  <br>
  &nbsp;&nbsp;&nbsp;&nbsp;Menytitel</blockquote>
<p>genom att l&auml;gga till ett antal mellanslag i b&ouml;rjan av texten. </p>
<p><b>Inaktivt menyobjekt  (avsnittstitel)</b></p>
<p>Du kan skapa avsnittstitlar, eller avaktivera enskilda menyobjekt, genom att b&ouml;rja texten med ett br&auml;dg&aring;rdstecken (#). Om du &auml;ndrar </p>
<blockquote>
  <span class="remark">fr&aring;n</span><br>
  <br>
  Ett menyobjekt<br>
  <br>
  <span class="remark">till</span><br>
  <br>
  #Ett menyobjekt</blockquote>
<p>s&aring; blir objektet avaktiverat (ej klickbart).</p>
<h4>Radbryta l&aring;nga menyobjekt</h4>
<p>N&auml;r ett menyobjekt &auml;r f&ouml;r l&aring;ngt f&ouml;r att f&aring; plats s&aring; kan man  l&auml;gga in en radbrytning genom att skriva in  ett <i>backslash</i> (\). Om menyobjektet &auml;ndras </p>
<blockquote> <span class="remark">fr&aring;n</span><br>
    <br>
  Ett mycket l&aring;ngt menyobjekt <br>
  <br>
  <span class="remark">till</span><br>
  <br>
  Ett mycket l&aring;ngt\menyobjekt</blockquote>
<p>s&aring; kommer det att brytas efter ordet &quot;l&aring;ngt&quot;.</p>
<p></p>
<p><b>Spara</b></p>
<p>Gl&ouml;m inte att klicka Spara n&auml;r du &auml;r klar. Detta permanentar dina &auml;ndringar och st&auml;nger dialogrutan Redigera meny. D&auml;refter visas den &auml;ndrade menyn p&aring; din webbsida.<br>
<span class="remark">I vissa enstaka fall kan du beh&ouml;va ladda om webbsidan manuellt innan &auml;ndringarna syns. </span></p>
<span class="textButton">&lt;<a href="javascript:window.close();">st&auml;ng f&ouml;nstret</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
