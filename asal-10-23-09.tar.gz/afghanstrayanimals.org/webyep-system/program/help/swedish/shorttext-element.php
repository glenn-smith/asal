<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->

<title><?php echo $webyep_sProductName?>
</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">st&auml;ng f&ouml;nstret</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?>
   : Kortare text</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>

<p>F&auml;ltet Kortare text kan anv&auml;ndas f&ouml;r t ex rubriker, titlar, produktnamn, priser och annan text som bara best&aring;r av en enda rad.   I motsats till f&auml;ltet L&auml;ngre text s&aring; kan bara webbdesignerns egen formatering anv&auml;ndas f&ouml;r f&auml;ltet   Kortare text.</p>
<h3>G&ouml;r s&aring; h&auml;r  </h3>
<p>Skriv in din text i textf&auml;ltet och klicka p&aring; Spara.</p>
<p>Redigeringsf&ouml;nstret st&auml;ngs och den &auml;ndrade texten visas p&aring; din webbsida.<br>
  <span class="remark">I vissa enstaka fall beh&ouml;ver du ladda om webbsidan manuellt   f&ouml;r att se &auml;ndringen.</span></p>
 <span class="textButton">&lt;<a href="javascript:window.close();">st&auml;ng f&ouml;nstret</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
