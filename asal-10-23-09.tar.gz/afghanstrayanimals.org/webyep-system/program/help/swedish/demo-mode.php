<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<!-- DW6 -->
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->

<title><?php echo $webyep_sProductName?>
</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">st&auml;ng f&ouml;nstret</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?>
   : Demol&auml;get</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>

<p>I Demol&auml;ge &auml;r alla normala 
  <?php echo $webyep_sProductName?>-funktioner  
  tillg&auml;ngliga. Den enda skillnaden j&auml;mf&ouml;rt med det licensierade l&auml;get &auml;r ett p&aring;minnelsef&ouml;nster som visas varje g&aring;ng bes&ouml;karen laddar in startsidan f&ouml;rsta g&aring;ngen. </p>
<h3>Varf&ouml;r  k&ouml;r 
  <?php echo $webyep_sProductName?>
i Demol&auml;ge?</h3>
<p>F&ouml;r att ingen giltigt licens installerats.<br>
  Ett licensnummer &auml;r giltigt om:</p>
<ul>
  <li>Det matchar webbsidans dom&auml;nnamn.<br>
      OBS!: Om din webbsida anv&auml;nder flera olika namn s&aring; kan du ev beh&ouml;va fler licenser (gratis). V&auml;nligen  <a href="mailto:webyep@obdev.at?subject=WebYep%2Badditional%2Blicense%2Bcodes">kontakta
      oss</a> i s&aring;dana fall.</li>
  <li>Det  matchar den <?php echo $webyep_sProductName?>-version som anv&auml;nds.</li>
</ul>
<h3>Hur skaffar jag en licens?</h3>
<p>Du kan k&ouml;pa <?php echo $webyep_sProductName?> licenser p&aring; <a href="http://www.obdev.at/webyep/order.html" target="webyep_order">v&aring;r webbsida</a>.</p>
<p>Hur aktiverar jag min licens?</p>
<ul>
  <li>St&auml;ng av din webbl&auml;sare.</li>
  <li>&Ouml;ppna webbl&auml;saren p&aring; nytt och g&aring; till en sida som nyttjar 
    <?php echo $webyep_sProductName?>
=&gt; F&ouml;nstret med p&aring;minnelsen om Demol&auml;ge visas.</li>
  <li>Ange ditt licensnummer.</li>
  <li>Klick knappen Spara licensenummer.</li>
</ul>
<h3><span class="textButton">&lt;<a href="javascript:window.close();">st&auml;ng f&ouml;nstret</a>&gt;</span></h3>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
