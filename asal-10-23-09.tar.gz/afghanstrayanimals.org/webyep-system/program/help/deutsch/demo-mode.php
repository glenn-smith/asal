<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">Hilfe schlie&szlig;en</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Hilfe: Demo-Modus</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<p>Im &quot;Demo-Modus&quot; k&ouml;nnen alle Funktionen von <?php echo $webyep_sProductName?> uneingeschr&auml;nkt 
   genutzt werden. Der einzige Unterschied zum normalen Betrieb ist, da&szlig; 
   das &quot;Demo-Modus&quot;-Fenster immer beim ersten Aufruf Ihrer Website 
   erscheint.</p>
<h3>Warum l&auml;uft <?php echo $webyep_sProductName?> im &quot;Demo-Modus&quot;?</h3>
<p>Weil noch kein korrekter Lizenzcode f&uuml;r Ihre Website gespeichert 
   wurde.<br>
Korrekt ist ein Lizenzcode wenn er:</p>
<ul>
   <li>zur Ihrer exakten Website-Adresse geh&ouml;rt (also zB. zu &quot;www.firma.com&quot;)<br>
     <strong>Vorsicht:</strong> Wenn Sie Ihre Website <strong>unter einer anderen
     Adresse</strong> aufrufen, brauchen
       Sie unter Umst&auml;nden einen Zweitcode. Bitte <a href="mailto:webyep@obdev.at?subject=WebYep%2BZweitcode">wenden Sie Sich in diesem Fall an uns</a>.</li>
   <li>zur verwendeten Version von <?php echo $webyep_sProductName?> geh&ouml;rt</li>
</ul>
<h3>Wie bekomme ich einen Lizenzcode?</h3>
<p>Sie k&ouml;nnen <?php echo $webyep_sProductName?>-Lizenzcodes &uuml;ber <a href="http://www.obdev.at/webyep/order-de.html" target="webyep_order">unsere Website</a> 
   erwerben.</p>
<h3>Wie speichere ich meinen Lizenzcode?</h3>
<ul>
<li>Beenden Sie Ihren Web-Browser (schlie&szlig;en Sie <em>alle</em> Fenster des Web-Browsers).</li>
<li>Rufen Sie eine Seite Ihrer Website auf, die <?php echo $webyep_sProductName?> verwendet.</li>
<li>Das &quot;Demo-Modus&quot;-Fenster wird angezeigt.</li>
<li>Geben Sie im &quot;Demo-Modus&quot;-Fenster in das Eingabefeld Ihren Lizenzcode ein.</li>
<li>Klicken Sie auf &quot;Lizenzcode speichern&quot;</li>
</ul>
<span class="textButton">&lt;<a href="javascript:window.close();">Hilfe schlie&szlig;en</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
