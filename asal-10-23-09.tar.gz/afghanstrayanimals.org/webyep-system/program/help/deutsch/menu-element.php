<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">Hilfe schlie&szlig;en</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Hilfe: Men&uuml;</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<h3>Beschreibung</h3>
<p>Im &quot;Men&uuml; Bearbeiten&quot;-Fenster k&ouml;nnen Sie die Eintr&auml;ge eines Men&uuml;s Ihrer Website ver&auml;ndern. Es k&ouml;nnen Men&uuml;punkte hinzugef&uuml;gt, ge&auml;ndert oder gel&ouml;scht werden und die Reihenfolge der Men&uuml;punkte (auch im Nachhinein) ver&auml;ndert werden.</p>
<p>Bitte beachten Sie, da&szlig; die hier vorgenommenen &Auml;nderungen <b>nach 
  dem Klick auf &quot;Speichern&quot;</b> unmittelbar wirksam werden und nicht 
  <b>r&uuml;ckg&auml;ngig gemacht</b> werden k&ouml;nnen!</p>
<h3>Vorgehensweise</h3>
<p><b>Men&uuml;punkt hinzuf&uuml;gen</b></p>
<p>Tragen Sie die Bezeichnung des neuen Men&uuml;punktes in das Texteingabefeld am unteren Rand ein und klicken Sie auf &quot;hinzuf&uuml;gen&quot;.</p>
<p><b>Men&uuml;punkt &auml;ndern</b></p>
<p>Selektieren Sie den zu &auml;ndernden Men&uuml;punkt in der Liste, tragen Sie die neue Bezeichnung in das Texteingabefeld am unteren Rand ein und klicken Sie auf &quot;&auml;ndern&quot;.</p>
<blockquote>
   <p><b>Wichtig:</b> <i>Erst</i> den alten Eintrag selektieren, <i>dann</i> Text 
    eingeben - und auf <i>&quot;&auml;ndern&quot;</i> klicken nicht vergessen!</p>
</blockquote>
<p><b>Men&uuml;punkt l&ouml;schen</b></p>
<p>Selektieren Sie den zu l&ouml;schenden Men&uuml;punkt in der Liste und klicken 
  Sie auf &quot;l&ouml;schen&quot;. Es erscheint eine Sicherheitsabfrage (&quot;Wirklich 
  l&ouml;schen...?&quot;), die mit &quot;Ja&quot; zu best&auml;tigen ist - aber 
  keine Sorge: Der Men&uuml;punkt und die zugeh&ouml;rige Webseite werden erst 
  tats&auml;chlich gel&ouml;scht, wenn Sie das &quot;Men&uuml; Bearbeiten&quot;-Fenster 
  mit dem Klick auf &quot;Speichern&quot; verlassen.</p>
<p><b>Men&uuml;punkte sortieren</b></p>
<p>Selektieren Sie einen Men&uuml;punkt, den Sie nach oben bzw. unten verschieben wollen und klicken Sie dann auf &quot;hinauf&quot; bzw. &quot;hinunter&quot;.</p>
<p><b>Men&uuml;punkt einr&uuml;cken bzw. Unterpunkt erzeugen</b></p>
<p>Um einen Unterpunkt in einem Men&uuml; zu erzeugen gen&uuml;gt es, dem betreffenden Men&uuml;punkt einige Leerzeichen (oder Unterstrich-Zeichen: &quot;_&quot;) in der Bezeichnung voran zu stellen. Wenn Sie als Bezeichnung eines Men&uuml;punktes also:
<blockquote>
<span class="remark">statt</span><br>
   <br>
Ein Men&uuml;punkt<br>
   <br>
   <span class="remark">einfach</span><br>
   <br>
   &nbsp;&nbsp;&nbsp;&nbsp;Ein Men&uuml;punkt</blockquote>
<p>eingeben, also einige Leerzeichen an den Beginn des Textes setzen, wird dieser Punkt einger&uuml;ckt und somit zum Unterpunkt.</p>
<p><b>Inaktiver Men&uuml;punkt (&Uuml;berschrift)</b></p>
<p>Um einen inaktiven Men&uuml;punkt zu erzeugen, der nicht angeklickt werden kann (zB. um eine &Uuml;berschrift &uuml;ber einige Men&uuml;punkte zu setzen) gen&uuml;gt es, dem betreffenden Men&uuml;punkt eine Raute (&quot;#&quot;) voran zu stellen. Wenn Sie als Bezeichnung eines Men&uuml;punktes also:
</p>
<blockquote>
<span class="remark">statt</span><br>
   <br>
Ein Men&uuml;punkt<br>
   <br>
   <span class="remark">einfach</span><br>
   <br>
   #Ein Men&uuml;punkt</blockquote>
<p>eingeben, also eine Raute an den Beginn des Textes setzen, wird dieser Punkt inaktiv dargestellt.</p>
<h4>Umrechen von langen Men&uuml;punkten</h4>
<p>Sollte ein Men&uuml;punkt einmal zu lang werden und in der Seite eine unansehnliche
  Darstellung erzeugen, k&ouml;nne Sie den Men&uuml;punkt auf mehrere Zeilen aufteilen,
  indem Sie an geeigneter Stelle (zB. nach einem Bindestrich oder Leerzeichen)
  das Zeichen &quot;\&quot; (umgekehrter Schr&auml;gstrich, Backslash) eingeben. Geben Sie als
  Men&uuml;punkt</p>
<blockquote> <span class="remark">statt</span><br>
    <br>
  Ein sehr langer Men&uuml;punkt<br>
  <br>
  <span class="remark">einfach</span><br>
  <br>
  Ein sehr\langer Men&uuml;punkt</blockquote>
<p>ein, dann wird nach &quot;sehr&quot; ein Zeilenumbruch im Men&uuml;punkt eingef&uuml;gt.</p>
<p></p>
<p><b>Speichern</b></p>
<p>Nachdem Sie die gew&uuml;nschten &Auml;nderungen an dem Men&uuml; vorgenommen haben, klicken Sie auf &quot;Speichern&quot;. Nach dem Speichern schlie&szlig;t sich das Eingabefenster und  Ihre ge&auml;nderte Webseite erscheint.<br>
   <span class="remark">(In seltenen F&auml;llen m&uuml;ssen sie noch den &quot;Seite Aktualisieren&quot;-Befehl Ihres Web-Browsers durchf&uuml;hren)</span></p>
<span class="textButton">&lt;<a href="javascript:window.close();">Hilfe schlie&szlig;en</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
