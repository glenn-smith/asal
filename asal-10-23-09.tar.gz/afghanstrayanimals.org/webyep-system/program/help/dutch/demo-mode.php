<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">sluit venster</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Demo
      versie</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<p>In de &quot;Demo versie&quot; zijn alle functies van <?php echo $webyep_sProductName?> beschikbaar. Het enige verschil met de gelicenceerde versie is dat de &quot;Demo versie&quot; elke eerste keer dat u uw website oproept een pop up venster zal tonen met een &quot;Demo melding&quot;.</p>
<h3>Waarom draait <?php echo $webyep_sProductName?> als &quot;Demo versie&quot;?</h3>
<p>Omdat er geen geldige licentiecode is ingevoerd.<br>
  Een licentiecode is geldig als:</p>
<ul>
  <li>hij exact overeenkomt met de naam (domein) van uw website.<br>
      Let op: als u met meerdere domeinnamen verwijst naar uw website, heeft u aanvullende (gratis) licentiecodes nodig. Om deze te verkrijgen kunt u contact opnemen met <a href="mailto:webyep@obdev.at?subject=WebYep%2Badditional%2Blicense%2Bcodes">ons</a>.</li>
  <li>hij overeenkomt met de gebruikte <?php echo $webyep_sProductName?> versie.</li>
</ul>
<h3>Hoe verkrijg ik een licentiecode?</h3>
<p>U kunt <?php echo $webyep_sProductName?> licentiecodes aanschaffen op <a href="http://www.obdev.at/webyep/order.html" target="webyep_order">onze website</a>.</p>
<p>Hoe voer ik mijn licentiecode in?</p>
<ul>
  <li>Sluit uw browser af (sluit <em>alle</em> vensters van uw webbrowser).</li>
  <li>Start de browser opnieuw op en open een pagina van uw website die gebruik maakt van <?php echo $webyep_sProductName?>=&gt;
    Het venster met de &quot;Demo melding&quot; zal verschijnen.</li>
  <li>Voer uw licentiecode in in het invoerveld &quot;Demo-Notice&quot;.</li>
  <li>Klik op de knop &quot;Bewaar licentie&quot;.</li>
</ul>
<h3>&nbsp;</h3>
<span class="textButton">&lt;<a href="javascript:window.close();">sluit venster</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
