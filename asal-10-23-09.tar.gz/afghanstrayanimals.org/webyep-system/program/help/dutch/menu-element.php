<?php
	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = "../..";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<html>
<head>
<!--
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at
-->
<title><?php echo $webyep_sProductName?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="../../styles.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<span class="textButton">&lt;<a href="javascript:window.close();">Sluit venster</a>&gt;</span><br>
<img src="../../images/nix.gif" width="8" height="8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top"><h1><?php echo $webyep_sProductName?> Help: Menu</h1></td>
    <td align="right" valign="top"><img src="../../images/logo.gif" align="top" border="0"><img src="../../images/nix.gif" width="8" height="8" align="top"></td>
</tr>
</table>
<div><img src="../../images/nix.gif" width="8" height="10"></div>
<h3>Omschrijving</h3>
<p>Het &quot;Bewerk Menu&quot; venster wordt gebruikt om menu-items toe te voegen en te verwijderen, en hun volgorde of eigenschapen te wijzigen.</p>
<p>Let op: de wijzigingen gaan pas in werking als u op de knop &quot;Bewaar&quot; klikt, maar <strong>u kunt ze dan niet meer ongedaan maken!</strong></p>
<h3>Gebruik</h3>
<p><b>Een menu-item toevoegen</b></p>
<p>Om een menu-item toe te voegen, voert u de namen van de items in het tekstveld (onder aan het venster) en klit u op de knop &quot;Voeg toe&quot;.</p>
<p><b>Een menu-item wijzigen</b></p>
<p>Selecteer het item dat u wilt wijzigen in de lijst, voer een nieuwe naam in in het tekstveld en klik op de knop &quot;Wijzig&quot;.</p>
<blockquote>
   <p><b>Belangrijk:</b> Selecteer <i>eerst</i> het item dat u wilt veranderen, voeg <i>dan</i> de tekst in en klik op de knop <i>&quot;Wijzig&quot;</i>!</p>
</blockquote>
<p><b>Een menu-item verwijderen</b></p>
<p>Selecteer het item dat u wilt verwijderen en klik daarna op de knop &quot;Verwijder&quot;. Een krijgt een bevestiging te zien (&quot;Item echt verwijderen...?&quot;) - klik &quot;ja&quot; om het item te verwijderen.
  Het item zal pas echt worden verwijderd als u het menu bewaart met de knop &quot;Bewaar&quot;.</p>
<p><b>De volgorde van het menu wijzigen</b></p>
<p>Selecteer een item en klik op de omhoog/omlaag iconen om het item te verplaatsen.</p>
<p><b>Submenu's aanmaken</b></p>
<p>Om een menu-item te wijzigen in een submenu item (indent) plaatst u eenvoudigweg enkele spaties (of underscores, &quot;_&quot;) aan het begin van de itemtitle. Als u de naam van een item wijzigt <blockquote>
<span class="remark">van</span><br>
   <br>
een menu-item<br>
   <br>
   <span class="remark">in</span><br>
   <br>
   &nbsp;&nbsp;&nbsp;&nbsp;een menu-item</blockquote>
<p>door enkele spaties toe te voegen aan het begin van een de naam van een item, zal het item inspringen naar rechts &#8211; hoe ver hangt af van het aantal spaties dat u invoegt.</p>
<p><b>Inactief menu-item (sectie titel)</b></p>
<p>Om een titel boven een menu sectie (een groep van menu- ofsubmenu-items) te plaatsen, kunt u een inactief menu-item invoegen (die niet klikbaar is) door een hash teken (&quot;#&quot;) aan het begin van zijn titel. Dus als je een item-titel verandert</p>
<blockquote>
<span class="remark">van</span><br>
   <br>
Een menu sectie<br>
   <br>
   <span class="remark">in</span><br>
   <br>
   #Een menu sectie</blockquote>
<p>zal het item inactief (niet klikbaar) worden en zal het worden weergegeven als een menu-sectie titel.</p>
<h4>Lange menu-item titels opbreken </h4>
<p>Als de titel van een item te lang is kan het de weergave van het menu verstoren (bijvoorbeeld door de breedte uit te rekken). Als dit gebeurt, kunt u de items-titels opbreken in verschillende regels door een &quot;\&quot; (backslash) op te nemen in de titel. Dus door de tekst van een menu-item te veranderen</p>
<blockquote> <span class="remark">van</span><br>
    <br>
  Een nogal lange menu item tekst<br>
  <br>
  <span class="remark">in</span><br>
  <br>
  Een nogal lange\menu item tekst</blockquote>
<p>voegt u een regeleinde in na &quot;lange&quot;.</p>
<p></p>
<p><b>Bewaren</b></p>
<p>Klik na de wijzigingen op de knop &quot;Bewaar&quot;. Daarmee maakt u alle wijzigingen permanent en sluit u het bewerkingsvenster. Daarna zal het gewijzigde menu worden weergegeven in uw webpagina.<br>
  <span class="remark">In sommmige uitzonderlijke gevallen kan het nodig zijn om de pagina in uw brwoser te verversen.</span></p>
<span class="textButton">&lt;<a href="javascript:window.close();">sluit venster</a>&gt;</span>
<hr>
<span class="remark"><?php echo $webyep_sCopyrightLine?></span>
</body>
</html>
