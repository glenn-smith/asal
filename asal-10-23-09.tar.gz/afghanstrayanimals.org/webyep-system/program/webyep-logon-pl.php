<?php
// WebYep
// (C) Objective Development Software GmbH
// http://www.obdev.at

	$webyep_bDocumentPage = false;
	$webyep_sIncludePath = ".";
	include_once("$webyep_sIncludePath/webyep.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><!-- InstanceBegin template="/Templates/panels.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="HeadPHPCode" -->
<?php
?>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="doctitle" -->
<title>WebYep Logon</title>
<!-- InstanceEndEditable --><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<link href="styles.css" rel="stylesheet" type="text/css">
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>

<body leftmargin="5" topmargin="5" marginwidth="5" marginheight="5"<?php if (isset($sOnLoadScript) && $sOnLoadScript) echo " onLoad='$sOnLoadScript'"; ?>>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="top"><h1><!-- InstanceBeginEditable name="headline" -->Logowanie WebYep<!-- InstanceEndEditable --></h1></td>
        <td align="right"><img src="images/logo.gif"></td>
      </tr>
    </table>
    <hr noshade size="1"></td>
  </tr>
  <tr>
    <td>  <!-- InstanceBeginEditable name="content" -->
	 <h1>WebYep</h1>
	 <h2>Zgrabny, l&#347;ni&#261;cy System Zarz&#261;dzania Tre&#347;ci&#261; CMS</h2>
	 <p><a href="<?php WYTSD("WebYepProductURL"); ?>">WebYep</a> jest kompaktowym CMS'em, w ktr&oacute;rym tworzenie edytowalnych stron internetowych jest bardzo szybkie i proste. W odr&oacute;&#380;nieniu od wi&#281;kszych system&oacute;w CMS, WebYep jest ekonomicz&#261; alternatyw&#261; dla mniejszych stron.. WebYep jest idealnym rozwi&#261;zaniem dla webmaster&oacute;w nie maj&#261;cych ochoty na zag&#322;ebianie si&#281; w sktypty serwerowe PHP, a jedynie chc&#261; stworzy&#263; zarz&#261;dzaln&#261; stron&#281; przy pomocy prostego narz&#281;dzia.</p>
	 <p class="warning">Aby edytowa&#263; strony w WebYep porzebna jest w&#322;&#261;czona w przegl&#261;darce obs&#322;uga<strong> JavaScript</strong>!</p>
	 <!-- InstanceEndEditable --></td></tr>
</table>
</body>
<!-- InstanceEnd --></html>
